<?php
/*
 * UWAGA WPISZ TUTAJ HASLO I NUMER KONTA GADU GADU
 * KTORE BEDZIE PELNILO ROLE BRAMKI CZYLI NADAWCY
 */ 
$numer_bramki = "";
$haslo_bramki = "";

/*
 * Jesli chcesz �eby wiadomo�ci oczekujace na odebranie na serwerze gg wy�wietli�y
 * sie r�wnie� przy u�ywaniu konta bramki zmie� poni�sz� warto�� na 1 
 * Dla 0 wiadomo�ci b�da wy�wietlane tylko w przypadku u�ywania w�asnego konta
 */ 

$POKAZ_OCZEKUJACE_WIADOMOSCI_DLA_BRAMKI = 0;


/*
 * Niedawno wprowadzono na sewerze blokade, kt�ra mia�a w zamy�le
 * zapobiega� spamowi, polega na blokowaniu wiadomo�ci kt�re
 * zawieraja linki np www.wp.pl lub moj@email.pl. a tak�e wyra�enia "www", "pl" itp
 * Jak ju� wycofaj� si� z tego b��du to zmie� poni�sz� warto�� na 0
 * 1 - to zamiana tych wyra�e� np www.wp.pl zmieni sie na w*w. wp. pl i unikni�cie zablokowania
 */

$DODAWAJ_SPACJE_W_LINKACH = 1;

/*
 * Teksty lepiej zmieni� na w�asne gdy� producent gadu-gadu moze chcie� odrzucac wiadomosci
 * z numer�w maj�cych te opisy w statusie, mo�na tak�e ustawic bez opisow czyli = ""
 */

$OPIS_W_STATUSIE_PO_ZALOGOWANIU = "Wiadomo�� z bramki www2gg";
$OPIS_W_STATUSIE_PO_WYLOGOWANIU = "Nie odpisuj tutaj!";




//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////


if (($numer_bramki == "") or ($haslo_bramki == ""))
    die("Wpisz do skrytpu numer i haslo bramki czyli jakies nieuzywane konto gg");


define ('HEADER','<HTML><HEAD><TITLE> Bramka www--&gt;GG </TITLE></HEAD>'
       .'<META HTTP-EQUIV = "Content-Type" CONTENT ="text/html; charset=ISO-8859-2" >'
       .'<META NAME="Author" CONTENT ="Piotr Mach <pm@ggadu.com>, http://gg.wha.la" ><BODY>');
define ('FOOTER','</BODY></HTML>');


error_reporting(E_ALL ^ E_NOTICE);  # jakby bylo za duzo b��d�w zmien na E_NONE ;)
require('klasy-gg.inc');        # w razie problemow wpisz pelna sciezke do pliku

/*
 * Dzieki temu bedzie dzialac na register_globals on i off
 * (php 4.2.0) a takze na track_vars on i off
 */

if ($HTTP_POST_VARS) foreach ($HTTP_POST_VARS as $Key => $Value) $$Key = $Value;
if ($HTTP_GET_VARS)  foreach ($HTTP_GET_VARS as $Key => $Value)  $$Key = $Value;
if ($_REQUEST)       foreach ($_REQUEST as $Key => $Value)       $$Key = $Value;

if (mb_check_encoding ($tresc, 'UTF-8'))
  $tresc = mb_convert_encoding($tresc,  'ISO-8859-2', 'UTF-8');

$tablica_komunikatow = array (
      GG_ACK_DELIVERED => 
       "<BR>\nWiadomo�� dla $adresat zosta�a odebrana",

      GG_ACK_QUEUED => 
       "<BR>\nWiadomo�� dla $adresat oczekuje w kolejce na odebranie.<BR>\n"
      ."Zostanie dostarczona gdy adresat w��czy gadu-gadu<BR>\n lub adresat"
      ." ma w tej chwili status <B>niewidoczny</B> b�d� \"tylko dla znajomych\"",

      GG_ACK_MBOXFULL => 
       "<BR>\nSkrzynka odbiorcza adresata jest pe�na, "
      ."wiadomo�� nie zosta�a dostarczona",
           
      0 =>
       "<BR>Wiadomos� nie zosta�a dostarczona, spr�buj jeszcze raz (od�wie� strone)"
);

# POCZATEK

if ( $tryb == "numer_wlasny" ) {      // Dla trybu z wlasnym numerkiem zostana 
	$pokaz_odebrane = true;             // wyswietlone wiadomosci oczekujace na serwerze GG
  $gg = new www2gg ($numer, $haslo);

} else {                              // dla trybu 'z bramki' lub dla uproszczonej wersji
  $gg = new www2gg ($numer_bramki, $haslo_bramki);
  $gg->auto_odpowiedz = "To jest jednostronna bramka www2gg, wiadomo�� nie dotar�a do nadawcy";
  
  $pokaz_odebrane = $POKAZ_OCZEKUJACE_WIADOMOSCI_DLA_BRAMKI; // Czy pokazac wiadomosci dla bramki
                                                             // ustaw w zmiennej na poczatku pliku
  $gg->ustaw_opisy($OPIS_W_STATUSIE_PO_ZALOGOWANIU, $OPIS_W_STATUSIE_PO_WYLOGOWANIU);
  
}

$gg->debug=false;
if ($debug) $gg->debug=true;

/* wyswietlenie roznych informacji, kt�re odebralismy */

echo HEADER;

if ($seq = $gg->wiadomosc ($adresat, $tresc, $DODAWAJ_SPACJE_W_LINKACH)) 
{
    /* statusu dostarczenia wiadomo�ci */
    echo $tablica_komunikatow[$gg->status_dostarczenia ($seq)];         

    /* pe�nego statusu adresata wiadomo�ci */
    echo txt::wyswietl_status_odbiorcy ($gg->status_kontaktu[$adresat]);

    /* opcjonalnie wiadomo�ci odebrancyh z serwera o ile by�y jakie� */
    if ($pokaz_odebrane) 
        echo txt::wyswietl_wiadomosci ($gg->wiadomosci);

} else {
    echo $gg->error;
}

echo FOOTER;
?>
