<HTML>
<HEAD>
<TITLE>Bramka www2gg</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-2">
<META HTTP-EQUIV="Cache-control" CONTENT="no-cache">
<style type="text/css">
<!--
.www2gg {  background: #E8E8FF;  width: 200px; height: 100px; border: solid; padding: 0px 0px}
-->
</style>
</HEAD>
<BODY bgcolor="#999999">
<BR>
PRZYK�AD Z INFOMRACJ� O WYS�ANIU NA TEJ SAMEJ STRONIE (WYMAGA PHP)<br>
<form name="" method="post" action="<? echo $PHP_SELF ?>">
  <table width="100%" border="0" bgcolor="#99CC66">
    <tr> 
      <td width="250"> 
        <textarea name="tresc" CLASS="www2gg"></textarea>
        <br>
        <input type="text" name="adresat" size="7" maxlength="7" style="background: #E8E8FF;  width: 100px;; border: none padding: 0px 0px">
        <input type="submit" value="WYSLIJ" style="background: #E8E8FF;  width: 100px;; border: none padding: 0px 0px" name="wyslij">
      </td>
      <td> 
        <?php if ($wyslij) require('www2gg.php'); ?>
      </td>
    </tr>
  </table>
</form>
<br>
<hr>
<P align="center"><b><a href="http://gg.wha.la"><font color="#3366FF">GG.WHA.LA</font></a></b></P>
</BODY>
</HTML>
